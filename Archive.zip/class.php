<?php

error_reporting(E_ALL);

class Gen
{
	protected $db;

	public function Start($words, $numbers, $special, $uppercase) {
		
		//Replace your database settings
		$username="root";
		$password="";
		$server="localhost";
		$database="pw";
		
		//Open a PDO record class
		try
		{
			$options = array(
				\PDO::ATTR_PERSISTENT => true
			);
			$this->db = new PDO("mysql:host=" . $server . ";dbname=" . $database, $username, $password, $options);
			$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->db->setAttribute(PDO::ATTR_AUTOCOMMIT, FALSE);
		}
		catch(\PDOException $err)
		{
			echo 'Error: '.$err->getMessage();
		}
		
		//Init the random generator
		srand((double)microtime()*1000000);
		
		$ret = (string)"";
		
		//Get count of words from database
		for ($i=1;$i<=$words;$i++) {
			
			//Select one record with random id
			$rw=(int)rand(1,478);
			
			try{
				//Build a SQL query
				$query = "SELECT *
						  FROM 
							`dictionary` 
						  WHERE  
							ID=" . $rw;
				$db_table = $this->db->prepare($query);
				$db_table->execute();
				if ($db_table->rowCount() == 0) return NULL;
				else{
					$res = $db_table->fetch(\PDO::FETCH_ASSOC);
					$ret.= strtolower($res['KeyWord']) . " ";
				}
			}
			catch(Exception $e){
				echo 'Fehler: '.$e->getMessage();
			}		
		}
		
		//Replace one char with a random number
		if ($numbers) {
			//One char from the whole string
			$ac=(int)rand(0,strlen($ret));
			$ac = ord(substr($ret,$ac,1));
			for ($i=0;$i<strlen($ret);$i++) {
				if (substr($ret,$i,1)==chr($ac)) {
					$ret=substr($ret,0,$i-1) . rand(0,9) . substr($ret,$i+1);
				}
			}
		}
		
		//Replace one char with a special char
		if ($special) {
			//Special char list
			$list="!#$%&'()*+,-<>@?=;:{[]}";
			$ac=(int)rand(0,strlen($ret));
			$ac = ord(substr($ret,$ac,1));
			for ($i=0;$i<strlen($ret);$i++) {
				if (substr($ret,$i,1)==chr($ac)) {
					$ret=substr($ret,0,$i-1) . substr($list,rand(0,23),1) . substr($ret,$i+1);
				}
			}
		}

		//Replace one char with uppercase
		if ($uppercase) {
			$ac=(int)rand(0,strlen($ret));
			$ac = ord(substr($ret,$ac,1));
			for ($i=0;$i<strlen($ret);$i++) {
				if (substr($ret,$i,1)==chr($ac)) {
					$ret=substr($ret,0,$i-1) . strtoupper(substr($ret,$i,1)) . substr($ret,$i+1);
				}
			}
		}

		return utf8_decode($ret);
		
	}
}