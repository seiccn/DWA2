<?php 
session_start();
error_reporting(-1); # Report all PHP errors
ini_set('display_errors',1);
?>

<!DOCTYPE html>
<html lang="en">
	
<head>

<!-- Basic configuration -->
<title>Portfolio of Stephanie Ness for Dynamic Web Applications</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="author" content="Stephanie Ness">
<meta name="description" content="Basic portfolio website for DWA15.">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="HTML, CSS, Portfolio">


<link rel="shortcut icon" href="img/icon.png">
<link rel="apple-touch-icon" href="img/touch.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/touch72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/touch114.png">



<!-- Patch for Internet Explorer -->
<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- Own CSS -->
<link href="css/custom.css" rel="stylesheet">

<!-- Bootstrap CSS File; in one line, smaller file size -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Embed respond.min.js from github scottdehl -->

<script src="js/respond.js"></script>

<!--  Fonts from https://www.google.com/fonts/ -->
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,300italic,700italic,400italic' rel='stylesheet' type='text/css'>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


<meta charset="utf-8">
<meta name="description" content="classmax"/>
<meta name="google" content=""/>
<meta name="googlebot" content="noindex,nofollow"/>
<meta name="keywords" content=""/>
<meta name="robots" content=""/>
<meta name="verify" content=""/>
</head>
<body>


<!-- Navigation fixed to the top -->
<!-- Navigation fixed to the top -->
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	<div class="container">
		<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">
                	
                
                Stephanie Ness Portfolio
                </a>
<!-- endtag of the div class="navbar-header" -->                 
		</div>
<!-- Navigation items -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.html">Project 1</a>
                    </li>
                    <li>
                        <a href="#">Project 2</a>
                    </li>
                    <li>
                        <a href="#">Project 3</a>
                    </li>
                     <li>
                        <a href="#">Project 4</a>
                    </li>
                </ul>
<!-- endtag of the class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" -->                
			</div>
<!-- endtag of the div class="container" -->
	</div>
<!-- endtag of the nav class="navbar navbar-default navbar-fixed-top" -->
</nav>


<!-- Header -->
<!-- Header -->
    <div class="customheader">

        <div class="container">

            <div class="row">
                <div class="col-lg-12">
                    <div class="greeting">
                        <h1>Project 2: </h1>
                        <hr class="customdivision">
 
                    </div>
                </div>
            </div>

        </div>
<!-- end of the container  -->

    </div>
<!-- end of my custom header -->

<?php

require_once('class.php');

if (isset($_POST['words'])) {
	
	$p_words=$_POST['words'];
	
	if (isset($_POST['numbers'])) {
		if ($_POST['numbers']=="on") {
			$p_numbers=true;
		} else {
			$p_numbers=false;
		}
	} else {
		$p_numbers=false;
	}

	if (isset($_POST['special'])) {
		if ($_POST['special']=="on") {
			$p_special=true;
		} else {
			$p_special=false;
		}
	} else {
		$p_special=false;
	}

	if (isset($_POST['uppercase'])) {
		if ($_POST['uppercase']=="on") {
			$p_uppercase=true;
		} else {
			$p_uppercase=false;
		}
	} else {
		$p_uppercase=false;
	}
	
	$pw=new Gen();
	echo $pw->Start($p_words, $p_numbers, $p_special, $p_uppercase);
} else {
	$p_words="";
	$p_numbers=0;
	$p_special=0;
	$p_uppercase=0;
}
?>

    <div class="content-section-a">

        <div class="container">

            <div class="row">
                <div class="col-lg-5 col-sm-6">
                    <div class="clearfix"></div>
                  <h2 class="boxheading">XKCD Style Calculator</h2>

<form action="index.php" method="POST">
	<TABLE>
		<TR>
			<TD>Number of words</TD>
			<TD><INPUT type="text" name="words" maxlength="26" size="26" value="<?php echo $p_words;?>"></TD>
		</TR>
		<TR>
			<TD>Use numbers</TD>
			<TD><INPUT type="checkbox" name="numbers"<?php if ($p_numbers) { echo " checked"; } ?>></TD>
		</TR>
		<TR>
			<TD>Use special chars</TD>
			<TD><INPUT type="checkbox" name="special"<?php if ($p_special) { echo " checked"; } ?>></TD>
		</TR>
		<TR>
			<TD>Use uppercase chars</TD>
			<TD><INPUT type="checkbox" name="uppercase"<?php if ($p_uppercase) { echo " checked"; } ?>></TD>
		</TR>
		<TR>
			<TD> </TD>
			<TD><INPUT type="submit" value="Generate password" name="B1"></TD>
		</TR>
	 </TABLE>
                </div>
                </div>
            </div>

        </div>
   </div>
</form>
</body>
</html>
